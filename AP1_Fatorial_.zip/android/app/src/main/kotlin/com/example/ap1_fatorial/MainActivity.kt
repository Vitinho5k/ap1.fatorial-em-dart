package com.example.ap1_fatorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
